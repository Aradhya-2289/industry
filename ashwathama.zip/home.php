<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
</head>
<style>
*
{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
.full-page
{
    height: 150%;
	width: 100%;
	background-image: linear-gradient(rgba(200,232,233),rgba(200,232,233)),url(images/bg-2.jpg);
	background-position: center;
	background-size: cover;
	position: absolute;
}
.navbar
{
    display: flex;
    align-items: center;
    padding: 20px;
    padding-left: 50px;
    padding-right: 30px;
    padding-top: 50px;
}
nav
{
    flex: 1;
    text-align: right;
}
nav ul 
{
    display: inline-block;
    list-style: none;
}
nav ul li
{
    display: inline-block;
    margin-right: 70px;
}
nav ul li a
{
    text-decoration: none;
    font-size: 20px;
    color: white;
    font-family: sans-serif;
}
nav ul li button
{
    font-size: 20px;
    color: white;
    outline: none;
    border: none;
    background: transparent;
    cursor: pointer;
    font-family: sans-serif;
}
nav ul li button:hover
{
    color: aqua;
}
nav ul li a:hover
{
    color:  aqua;
}
}
a
{
    text-decoration: none;
    color: palevioletred;
    font-size: 28px;
}
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
}

header {
  background-color: #333;
  color: #fff;
  padding: 20px;
}

nav ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
}

nav ul li {
  display: inline-block;
  margin-right: 10px;
}

nav ul li a {
  color: #fff;
  text-decoration: none;
}

main {
  padding: 20px;
}

h1, h2, h3 {
  margin: 0;
}

section {
  margin-bottom: 30px;
}

form {
  display: flex;
  margin-bottom: 20px;
}

input[type="text"] {
  width: 200px;
  padding: 10px;
  margin-right: 10px;
}

button {
  padding: 10px 20px;
  background-color: #333;
  color: #fff;
  border: none;
  cursor: pointer;
}

.consultant-card, .project-card {
  border: 1px solid #ccc;
  padding: 20px;
  margin-bottom: 10px;
}

footer {
  background-color: #333;
  color: #fff;
  padding: 20px;
</style>
<body>
    <div class="full-page">
        <div class="navbar">
            <div>
                <a href='website.html'>Seek Coding</a>
            </div>
            <nav>
                <ul id='MenuItems'>
				<li><button class='loginbtn' onclick="document.getElementById('login-form').style.display='block'" style="width:auto;">Login</button></li>
                    <li><a href='home.php'>Home</a></li>
                    <li><a href='about1.html'>About Us</a></li>
                    
                </ul>
            </nav>
        </div>
		 <main>
    <section id="search-section">
      <h2>Find IT Consultants</h2>
      <form action='search.php' method='post'>
        <input type="text" name="sea" placeholder="Search by expertise">
	
        <input type="text" placeholder="Search by location">
        <button type="submit">Search</button>
      </form>
    </section>

    <section id="consultant-list-section">
      <h2><button>Consultant List</button></h2>
	  <div class="consultant-card">
        <h3>Aradhya</h3>
        <p>Expertise: Web Development</p>
        <p>Location: Mysuru</p>
        <button>Contact</button>
      </div>
      <!-- Additional consultant cards -->
	  <div class="consultant-card">
        <h3>Varshitha</h3>
        <p>Expertise: Block chain</p>
        <p>Location: kerala</p>
        <button>Contact</button>
      </div>
	  <div class="consultant-card">
        <h3>Kiran</h3>
        <p>Expertise: network analysis</p>
        <p>Location: Mysuru</p>
        <button>Contact</button>
      </div>
    </section>

    <section id="project-list-section">
      <h2>Project List</h2>
      <div class="project-card">
        <h3>Website Redesign</h3>
        <p>Business Name: ABCD</p>
        <p>Location: Bengaluru</p>
        <button>Contact</button>
      </div>
      <!-- Additional project cards -->
    </section>
  </main>

  <footer>
  </footer>

</div>
</body>
</html>
</body>
</html>