</html>
<?php
include "dbconfig.php";
$email id=$_POST['email id'];
$password=$_POST['enter password'];
//echo $name,$usn,$mobile;
$sql="select * from sync where email id='$email id' and password='$password' ";
$result=mysqli_query($conn,$sql);

    if(mysqli_num_rows($result)==1)
{
echo "login success"

}
else
{
echo "failure";
}
mysqli_close($conn);
?>

</html>