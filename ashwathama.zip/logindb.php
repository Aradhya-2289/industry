<?php
include "dbconfig.php";
$emailid=$_POST['emailid'];
$password=$_POST['password'];
//echo $name,$usn,$mobile;
$sql="select from sync where password='$password'";
$result=mysqli_query($conn,$sql);

if(mysqli_num_rows($result)==1)
{
echo "login success";
header('refresh:1,url=home.php');

}
else{
echo "failure";
}
mysqli_close($conn);
?>
