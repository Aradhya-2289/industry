<?php
include "dbconfig.php";
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$emailid=$_POST['emailid'];
$password=$_POST['password'];
$sql="insert into sync(firstname,lastname,emailid,password)value('$firstname','$lastname','$emailid','$password')";
if(mysqli_query($conn,$sql))
{
echo "successful";
header('refresh:0,url=home.php');
}
else
{
echo "invalid";
}
mysqli_close($conn);
?>

