<?php
$server="localhost";
$user="root";
$pass="";
$db="login";
$conn=mysqli_connect($server,$user,$pass,$db);
if($conn)
{
	echo "connection successsful";
}
else
{
	echo "connection failure";
}
?>