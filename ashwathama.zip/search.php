<?php
include "dbconfig.php";
$location=$_POST['location'];
$expertise=$_POST['expertise'];
if(isset($_POST['search']))
$sql="select from search(location,expertise)values('$location','$expertise');
$search=$_POST['sea'];

{
	$sql="select from search where location like '%search%';
	$result=$conn->query($sql);
	if($result->num_rows>0)
	{
		while($row=$result->fetch_assoc())
		{
			echo $row["location"].
			header('refresh:0,url=home.php');
		}
	}
}
?>
